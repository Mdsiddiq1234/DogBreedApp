package com.disney.studios.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.disney.studios.data.DogBreed;
import com.disney.studios.exception.ResourceNotFoundException;

@Service
public class BreedService {

	@Autowired
	GetRepository getRepo;

	public Map<String, List<DogBreed>> getAllDogByBreed() {
		List<DogBreed> dogBreed = getRepo.findAll();
		Map<String, List<DogBreed>> dogByBreed = dogBreed.stream()
				.collect(Collectors.groupingBy(DogBreed::getBreed, Collectors.toList()));
		return dogByBreed;
	}

	public List<DogBreed> getAllDog(@PathVariable String breedName) throws ResourceNotFoundException {

		List<DogBreed> breed = getRepo.getDogByBreedName(breedName);
		if (breed.isEmpty()) {
			throw new ResourceNotFoundException("Breed Name does not exist in Database = " + breedName);
		}
		return breed;

	}

	public int getUpVote(int id) throws ResourceNotFoundException {
		// TODO Auto-generated method stub
		try {
			DogBreed dogById = getRepo.getOne(id);
			dogById.setUpVote(dogById.getUpVote() + 1);
			getRepo.save(dogById);
			return dogById.getUpVote();
		} catch (Exception e) {
			throw new ResourceNotFoundException("Dog id does not exist in Database =" + id);

		}
	}

	public int getDownVote(int id) throws ResourceNotFoundException {
		try {
			DogBreed dogById = getRepo.getOne(id);
			dogById.setDownVote(dogById.getDownVote() + 1);
			getRepo.save(dogById);
			return dogById.getDownVote();
		} catch (Exception e) {
			throw new ResourceNotFoundException("Dog id does not exist in Database -" + id);

		}
	}
	
	public Optional<DogBreed> getAllDetails(int id) throws ResourceNotFoundException {
			
		Optional<DogBreed> dogById = getRepo.findById(id);
			if(dogById.isEmpty()) {
				throw new ResourceNotFoundException("Dog does not exist in Database =" + id);

			}
			return dogById;

		
	}


}
