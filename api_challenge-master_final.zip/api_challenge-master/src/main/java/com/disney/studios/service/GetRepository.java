package com.disney.studios.service;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.disney.studios.data.DogBreed;

import org.springframework.data.jpa.repository.Modifying;



@Repository
public interface GetRepository extends JpaRepository<DogBreed, Integer> {
	 

	@Query(value = "SELECT * FROM dog_breed where breed = ?1", nativeQuery = true)
	    List<DogBreed> getDogByBreedName(String breed);
	
	@Query(value = "SELECT * FROM dog_breed where id = ?1", nativeQuery = true)
    List<DogBreed> getDogByBreedId(int breed);

}
