package com.disney.studios.data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
public class DogBreed {
	
	@Id
	public int id ;
	public String breed ;
	public String pathImage;
	public int upVote;
	public int downVote;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBreed() {
		return breed;
	}
	public void setBreed(String breed) {
		this.breed = breed;
	}
	public String getPathImage() {
		return pathImage;
	}
	public void setPathImage(String pathImage) {
		this.pathImage = pathImage;
	}
	public int getUpVote() {
		return upVote;
	}
	public void setUpVote(int upVote) {
		this.upVote = upVote;
	}
	public int getDownVote() {
		return downVote;
	}
	public void setDownVote(int downVote) {
		this.downVote = downVote;
	}
	public DogBreed() {
		super();
	}
	public DogBreed(int id, String breed, String pathImage , int upVote , int downVote) {
		super();
		this.id = id;
		this.upVote = upVote ;
		this.downVote = downVote ;
		this.breed = breed;
		this.pathImage = pathImage;
	}
	
	
	@Override
	public String toString() {
		return "DogBreed [id=" + id + ", breed=" + breed + ", pathImage=" + pathImage + "]";
	}
	

}
