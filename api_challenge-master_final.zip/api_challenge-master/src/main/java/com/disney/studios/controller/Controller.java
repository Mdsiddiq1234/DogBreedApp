package com.disney.studios.controller;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.disney.studios.data.DogBreed;
import com.disney.studios.exception.ResourceNotFoundException;
import com.disney.studios.service.BreedService;

@RestController
public class Controller {
	
	@Autowired
	BreedService service;
	
	@GetMapping("/findAllDog")
	public Map<String, List<DogBreed>> getAllDog(){
		
		return service.getAllDogByBreed();
		
	}
	@GetMapping("/findAllDog/{breedName}")
	public List<DogBreed> getAllDog(@PathVariable String breedName) throws ResourceNotFoundException{
		
		return service.getAllDog(breedName);
		
	}
	@GetMapping("/getUpVote/{id}")
	public int getUpVote(@PathVariable int id) throws ResourceNotFoundException{
		
		return service.getUpVote(id);
		
	}
	@GetMapping("/getDownVote/{id}")
	public int getdownVote(@PathVariable int id) throws ResourceNotFoundException{
		
		return service.getDownVote(id);
		
	}
	@GetMapping("/getDogDetails/{id}")
	public Optional<DogBreed> getAllDetails(@PathVariable int id) throws ResourceNotFoundException{
		
		return service.getAllDetails(id);
		
	}


}
